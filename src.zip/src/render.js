import mainTemplate from './src/templates/main.html!text'

export async function render() {
    return mainTemplate;
}
