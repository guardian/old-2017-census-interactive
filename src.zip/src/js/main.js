var el = document.createElement('script');
el.src = '<%= path %>/app.js';
document.body.appendChild(el);
